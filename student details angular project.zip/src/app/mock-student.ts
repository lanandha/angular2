import { Student } from './student';

export const STUDENTS: Student[] = [
  { id: 1, name: 'Ramesh',dept:'ECE',place:'Trichy' },
  { id: 2, name: 'Naveen',dept:'ECE',place:'Dharmapuri' },
  { id: 3, name: 'Muthurathinam',dept:'ECE',place:'Tirupur' },
  { id: 4, name: 'Murugan',dept:'ECE',place:'Tanjavur' },
  { id: 5, name: 'Vijay',dept:'ECE',place:'Cuddalore' },
  { id: 6, name: 'Saravanan',dept:'MECH',place:'Palani' },
  { id: 7, name: 'Sudharason',dept:'Civil',place:'Nagapattinam' },
  { id: 8, name: 'Balaji',dept:'ECE',place:'Dindukal' },
  { id: 9, name: 'Ram',dept:'EEE',place:'Erode' },
  { id: 10, name: 'Ganesh',dept:'EEE',place:'Rasipuram' }
];
