export interface Student {
  id:number;
  name:string;
  dept:string;
  place:string;
}